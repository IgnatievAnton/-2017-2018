#include <stdio.h>
extern "C"
{
#include "jpeglib.h"
}
#include <setjmp.h>
#include <fstream>
#include <CL/cl.h>
#include <stdio.h>
#include <string>
#include <io.h>

#define DCTSIZE		    8
#define SIZE			16
#define DCTSIZE2	    64

typedef unsigned char uchar;
typedef unsigned short ushort;

static const double aanscalefactor[DCTSIZE] =
{
  1.0, 1.3870398453221475, 1.3065629648763766, 1.1758756024193588,
  1.0, 0.7856949583871022, 0.5411961001461971, 0.2758993792829431,
};

void jpeg_init_fdct_table(const ushort *quantptr, float quant_table[DCTSIZE2])
{
  for (int row = 0, i = 0; row < DCTSIZE; row++)
    for (int col = 0; col < DCTSIZE; i++, col++)
      quant_table[i] = 0.125 / (aanscalefactor[row] * aanscalefactor[col] * quantptr[i]); // 1/64
}

void jpeg_init_idct_table(const ushort *quantptr, float quant_table[DCTSIZE2])
{
  for (int row = 0, i = 0; row < DCTSIZE; row++)
    for (int col = 0; col < DCTSIZE; i++, col++)
      quant_table[i] = quantptr[i] * aanscalefactor[row] * aanscalefactor[col] * 0.125;
}

struct my_error_mgr {
  struct jpeg_error_mgr pub;

  jmp_buf setjmp_buffer;
};

typedef struct my_error_mgr * my_error_ptr;

METHODDEF(void)
my_error_exit(j_common_ptr cinfo)
{
  my_error_ptr myerr = (my_error_ptr)cinfo->err;

  (*cinfo->err->output_message) (cinfo);

  longjmp(myerr->setjmp_buffer, 1);
}

GLOBAL(uchar*)
read_JPEG_file(char * filename, int &width, int &height, ushort *quant_table)
{
  struct jpeg_decompress_struct cinfo;

  struct my_error_mgr jerr;
  FILE * infile;
  JSAMPARRAY buffer;
  int row_stride;
  //FILE *out_file;

  if ((infile = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "can't open %s\n", filename);
    return 0;
  }

  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = my_error_exit;
  if (setjmp(jerr.setjmp_buffer)) {
    jpeg_destroy_decompress(&cinfo);
    fclose(infile);
    return 0;
  }

  jpeg_create_decompress(&cinfo);
  jpeg_stdio_src(&cinfo, infile);


  (void)jpeg_read_header(&cinfo, TRUE);
  cinfo.out_color_space = JCS_GRAYSCALE;
  cinfo.image_width = cinfo.image_width + 7 & ~7;
  cinfo.image_height = cinfo.image_height + 7 & ~7;

  (void)jpeg_start_decompress(&cinfo);
  row_stride = cinfo.output_width * cinfo.output_components;

  buffer = (*cinfo.mem->alloc_sarray)
    ((j_common_ptr)&cinfo, JPOOL_IMAGE, row_stride, 1);

  uchar *data = new uchar[cinfo.output_width*cinfo.output_height];
  int row_count = 0;
  while (cinfo.output_scanline < cinfo.output_height)
  {
    (void)jpeg_read_scanlines(&cinfo, buffer, 1);
    for (int i = 0; i < cinfo.output_width; i++)
    {
      data[row_count*cinfo.output_width + i] = buffer[0][i];
    }
    row_count++;
  }
  width = cinfo.output_width;
  height = cinfo.output_height;

  JQUANT_TBL **table = cinfo.quant_tbl_ptrs;
  for (int i = 0; i < DCTSIZE2; i++)
  {
    quant_table[i] = table[0]->quantval[i];
  }

  (void)jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);

  fclose(infile);

  return data;
}

void write_file(const int width, const int height, uchar *data)
{
  FILE *out_file;
  if ((out_file = fopen("res.pgm", "wb")) == NULL)
    printf("���� ���������� ������� ��� �������\n");
  else {
    fprintf(out_file, "P5\n%i %i\n255\n", width, height);
    fwrite(data, 1, width*height, out_file);
  }

}

void divide(ushort *src, int width, int height, uchar *dst)
{
	for (int j = 0; j < height; j++)
	{
		int ky = j < DCTSIZE ? j + 1 : j > height - DCTSIZE ? height - j : DCTSIZE;
		for (int i = 0; i < width; i++)
		{
			int kx = i < DCTSIZE ? i + 1 : i > width - DCTSIZE ? width - i : DCTSIZE;
			//dst[i + j*width] = (uchar)(src[i + j*width] / 64);
			dst[i + j*width] = (uchar)(src[i + j*width] / (kx*ky));
		}
	}
}

int main()
{
  uchar *data;
  int width;
  int height;
  ushort quant_table[DCTSIZE2];
  data = read_JPEG_file("testimg.jpg", width, height, quant_table);

  float ftable[DCTSIZE2], itable[DCTSIZE2];
  jpeg_init_fdct_table(quant_table, ftable);
  jpeg_init_idct_table(quant_table, itable);

  uchar *result = new uchar[width * height];
  memset(result, 0, width * height);
  
  cl_uint num_platforms = 0;
  clGetPlatformIDs(0, NULL, &num_platforms);
  cl_platform_id *plt = new cl_platform_id[num_platforms];
  clGetPlatformIDs(num_platforms, plt, NULL);

  cl_device_id *device = NULL;
  for (int i = 0; i < num_platforms; i++)
  {
	  cl_device_type device_type = CL_DEVICE_TYPE_GPU;
	  cl_uint num_devices = 0;
	  clGetDeviceIDs(plt[i], device_type, 0, NULL, &num_devices);

	  if (num_devices != 0)
	  {
		  device = new cl_device_id[num_devices];
		  clGetDeviceIDs(plt[i], device_type, num_devices, device, NULL);
		  break;
	  }
  }

  if (device == NULL)
  {
	  cl_device_type device_type = CL_DEVICE_TYPE_CPU;
	  for (int i = 0; i < num_platforms; i++)
	  {
		  cl_uint num_devices = 0;
		  clGetDeviceIDs(plt[i], device_type, 0, NULL, &num_devices);
		  printf("NUM OF DEVICE CPU= %d\n\n", num_devices);

		  if (num_devices != 0)
		  {
			  device = new cl_device_id[num_devices];
			  clGetDeviceIDs(plt[i], device_type, num_devices, &device[0], NULL);
			  break;
		  }
	  }

  }

  cl_context context;
  cl_int errContext;
  context = clCreateContext(NULL, 1, &device[0], NULL, NULL, &errContext);
  if (errContext != CL_SUCCESS)
  {
	  printf("ERROR CONTEXT = %i\n\n", errContext);
  }

  cl_command_queue com_queue;
  cl_int errcodeQueue;
  com_queue = clCreateCommandQueue(context, device[0], CL_QUEUE_PROFILING_ENABLE, &errcodeQueue);
  if (errcodeQueue != CL_SUCCESS)
  {
	  printf("ERROR COMMAND QUEUE = %i\n\n", errcodeQueue);
  }

  FILE *pFile;
  size_t  sFile;
  char *buffer;
  size_t read_result;
  pFile = fopen("jpeg_compress.cl", "rb");
  sFile = _filelength(fileno(pFile));
  buffer = (char*)malloc(sizeof(char)*sFile);
  read_result = fread(buffer, 1, sFile, pFile);
  if (!read_result)
  {
	  printf("result of read  = %d\n\n", read_result);
  }

  const char *string = buffer;
  cl_program program = clCreateProgramWithSource(context, 1, &string, &sFile, NULL);

  cl_int errProgramm;

  errProgramm = clBuildProgram(program, 1, &device[0], " ", NULL, NULL);
  if (errProgramm != CL_SUCCESS)
  {
	  printf("errProgramm  = %d\n\n", errProgramm);
  }

  char buildLog[20480];
  clGetProgramBuildInfo(program, device[0], CL_PROGRAM_BUILD_LOG, 20480, buildLog, NULL);
  printf("BUILD LOG = %s\n\n", buildLog);

  const char *nameOfKernel_main = "jpeg_proc";

  int kernel_err;
  cl_kernel kernel_main = clCreateKernel(program, nameOfKernel_main, &kernel_err);
  if (kernel_err != CL_SUCCESS)
  {
	  printf("KERNEL ERROR = %i\n\n", kernel_err);
  }

  int size = width*height;

  ushort *tmp_res = new ushort[width * height];
  memset(tmp_res, 0, width * height);

  cl_mem buf_data = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(uchar)*size, NULL, NULL);
  cl_mem buf_result = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(ushort)*size, NULL, NULL);
  cl_mem buf_ftable = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float)*DCTSIZE2, NULL, NULL);
  cl_mem buf_itable = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float)*DCTSIZE2, NULL, NULL);
  int offset = 0;

  int err_setParam;
  err_setParam = clSetKernelArg(kernel_main, 0, sizeof(buf_data), &buf_data);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_data =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 1, sizeof(buf_result), &buf_result);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_result =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 2, sizeof(width), &width);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set width =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 3, sizeof(height), &height);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set height =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 4, sizeof(buf_ftable), &buf_ftable);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_ftable =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 5, sizeof(buf_itable), &buf_itable);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_itable =  %i\n", err_setParam);
  }
  err_setParam = clSetKernelArg(kernel_main, 6, sizeof(offset), &offset);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_itable =  %i\n", err_setParam);
  }

  int errWr;
  errWr = clEnqueueWriteBuffer(com_queue, buf_data, CL_FALSE, 0, sizeof(uchar)*size, data, NULL, NULL, NULL);
  if (errWr != CL_SUCCESS)
  {
	  printf("write buf_data = %i\n", errWr);
  }
  errWr = clEnqueueWriteBuffer(com_queue, buf_ftable, CL_FALSE, 0, sizeof(float)*DCTSIZE2, ftable, NULL, NULL, NULL);
  if (errWr != CL_SUCCESS)
  {
	  printf("write buf_ftable = %i\n", errWr);
  }
  errWr = clEnqueueWriteBuffer(com_queue, buf_itable, CL_FALSE, 0, sizeof(float)*DCTSIZE2, itable, NULL, NULL, NULL);
  if (errWr != CL_SUCCESS)
  {
	  printf("write buf_itable = %i\n", errWr);
  }

  size_t global_work_size[] = {(width/SIZE)*DCTSIZE, (height /SIZE)*DCTSIZE };
  const size_t local_work_size[] = {DCTSIZE, DCTSIZE};
  cl_event event = 0;

  // kernel 1
  errWr = clEnqueueNDRangeKernel(com_queue, kernel_main, 2, 0, global_work_size, local_work_size, NULL, NULL, &event);
  if (errWr != CL_SUCCESS)
  {
	printf("NDRangeKernel = %i\n",errWr);
  }

  // kernel 2
  offset = DCTSIZE;
  err_setParam = clSetKernelArg(kernel_main, 6, sizeof(offset), &offset);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_itable =  %i\n", err_setParam);
  }
  global_work_size[0] = ((width - DCTSIZE) / SIZE)*DCTSIZE;
  errWr = clEnqueueNDRangeKernel(com_queue, kernel_main, 2, 0, global_work_size, local_work_size, NULL, NULL, &event);
  if (errWr != CL_SUCCESS)
  {
	  printf("NDRangeKernel = %i\n", errWr);
  }

  // kernel 3
  offset = DCTSIZE * width;
  err_setParam = clSetKernelArg(kernel_main, 6, sizeof(offset), &offset);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_itable =  %i\n", err_setParam);
  }
  global_work_size[0] = (width / SIZE)*DCTSIZE;
  global_work_size[1] = ((height - DCTSIZE) / SIZE)*DCTSIZE;
  errWr = clEnqueueNDRangeKernel(com_queue, kernel_main, 2, 0, global_work_size, local_work_size, NULL, NULL, &event);
  if (errWr != CL_SUCCESS)
  {
	  printf("NDRangeKernel = %i\n", errWr);
  }

  // kernel 4
  offset = DCTSIZE * width + 8;
  err_setParam = clSetKernelArg(kernel_main, 6, sizeof(offset), &offset);
  if (err_setParam != CL_SUCCESS)
  {
	  printf("set buf_itable =  %i\n", err_setParam);
  }
  global_work_size[0] = ((width - DCTSIZE) / SIZE)*DCTSIZE;
  errWr = clEnqueueNDRangeKernel(com_queue, kernel_main, 2, 0, global_work_size, local_work_size, NULL, NULL, &event);
  if (errWr != CL_SUCCESS)
  {
	  printf("NDRangeKernel = %i\n", errWr);
  }

  errWr = clEnqueueReadBuffer(com_queue, buf_result, CL_TRUE, 0, sizeof(ushort)*size, tmp_res, NULL, NULL, NULL);
  if (errWr != CL_SUCCESS)
  {
	  printf("write buf_result = %i\n\n", errWr);
  }

  divide(tmp_res, width, height, result);

  write_file(width, height, result);

  delete data;
  delete result;

  return 0;
}

//

